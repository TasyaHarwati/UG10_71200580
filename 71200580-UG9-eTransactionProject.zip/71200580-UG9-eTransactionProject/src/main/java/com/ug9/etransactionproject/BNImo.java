package com.ug9.etransactionproject;

public class BNImo extends  MobileBanking{
}
