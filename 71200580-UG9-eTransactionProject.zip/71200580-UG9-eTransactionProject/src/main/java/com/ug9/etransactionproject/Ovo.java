package com.ug9.etransactionproject;

public class Ovo extends MobileWallet{

}
