package com.ug9.etransactionproject;

public class BRImo extends MobileBanking{
}
